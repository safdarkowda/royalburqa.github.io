package com.safdarkowda.cavista.network;

import com.safdarkowda.cavista.model.Photos;
import com.safdarkowda.cavista.model.RegisterBody;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Query;

public interface GetDataService {

    @GET("1")
    Call<RegisterBody> getAllPhotos(@Query("q") String id, @Header("Authorization") String auth);
}
