package com.safdarkowda.cavista;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.paging.PagedList;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.SearchView;
import android.widget.Toast;

import com.safdarkowda.cavista.adaper.PhotosAdapter;
import com.safdarkowda.cavista.model.Image;
import com.safdarkowda.cavista.model.PhotoDataSource;
import com.safdarkowda.cavista.model.Photos;
import com.safdarkowda.cavista.viewmodel.MainActivityViewModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {
    MainActivityViewModel mainActivityViewModel;

    RecyclerView photoRecylerview;
    public static  int s=1;
    public static String value="vanilla";
    List<Image> list=new ArrayList<>();

    SearchView searchView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       photoRecylerview=(RecyclerView)findViewById(R.id.recylerview);
       searchView=(SearchView)findViewById(R.id.searchView);
        if(getIntent().getStringExtra("title")!=null) {
            value=getIntent().getStringExtra("title");
        }

        s=1;

        mainActivityViewModel = ViewModelProviders.of(this).get(MainActivityViewModel.class);

        photoRecylerview.setLayoutManager(new GridLayoutManager(this,2));



        mainActivityViewModel.getPagedListLiveData().observe(this, new Observer<PagedList<Photos>>() {
            @Override
            public void onChanged(@Nullable PagedList<Photos> photos) {

                PhotosAdapter photosAdapter = new PhotosAdapter(MainActivity.this);
                photosAdapter.submitList(photos);
                photoRecylerview.setAdapter(photosAdapter);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

value=query;
                Toast.makeText(MainActivity.this, value,Toast.LENGTH_LONG).show();
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                intent.putExtra("title",query);
               startActivity(intent);
               finish();
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {

                return false;
            }
        });
    }


}