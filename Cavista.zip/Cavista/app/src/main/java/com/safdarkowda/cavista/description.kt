package com.safdarkowda.cavista

import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import com.safdarkowda.cavista.database.AppDb
import com.safdarkowda.cavista.database.BookEntity
import com.squareup.picasso.Picasso
import java.util.ArrayList


class description : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)
        var list:List<BookEntity>
        var title:String=intent.getStringExtra("title")
        var imageurl:String=intent.getStringExtra("url")
        var  id:Int=intent.getIntExtra("id",0)
        val editText = findViewById<EditText>(R.id.editText)
        val textview = findViewById<TextView>(R.id.text)

        val myImageView = findViewById<ImageView>(R.id.imageView)
        val imageView = ImageView(this)
      //  imageView.setImageResource(R.drawable.drawable_id)
       /* val bitmap = intent.getParcelableExtra("BitmapImage") as Bitmap
          imageView.setImageBitmap(bitmap)*/
        val text = editText.text



        Picasso.get()
                .load(imageurl)
                .into(myImageView)
        var db= Room.databaseBuilder(applicationContext, AppDb::class.java,"BookDB").allowMainThreadQueries().build()
        var bookEntity = BookEntity()



        val button = findViewById<Button>(R.id.b)
        button?.setOnClickListener()
        {
            bookEntity.bookId = id
            bookEntity.bookName = text.toString()
            db.bookDao().saveBooks(bookEntity)
            Log.i("id", "Id:  : "+id);

    }
        list=db.bookDao().getAllBooks()
        for (item in list)
        {
            if ((item.bookId)==(id))
                    {
                        textview.setText(item.bookName)
                    }
        }
     /*   db.bookDao().getAllBooks().forEach()
        {
            Log.i("Fetch Records", "Id:  : ${it.bookId}")
            Log.i("Fetch Records", "Name:  : ${it.bookName}")
            textview.setText(it.bookName)

        }
*/
    //view data







        //

        val actionbar = supportActionBar
        //set actionbar title
        actionbar!!.title = title
        //set back button
        actionbar.setDisplayHomeAsUpEnabled(true)
        actionbar.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }


}
