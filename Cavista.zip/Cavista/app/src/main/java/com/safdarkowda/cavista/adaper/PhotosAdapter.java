package com.safdarkowda.cavista.adaper;


import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.paging.PagedListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.safdarkowda.cavista.R;
import com.safdarkowda.cavista.description;
import com.safdarkowda.cavista.model.Image;
import com.safdarkowda.cavista.model.Photos;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

public class PhotosAdapter extends PagedListAdapter<Photos,PhotosAdapter.PhotoViewHolder> {
    private Context context;
    String title,imageurl;
    int id;
    public PhotosAdapter(Context context) {

        super(Photos.CALLBACK);
        this.context = context;
    }

    @NonNull
    @Override
    public PhotoViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View view = layoutInflater.inflate(R.layout.list_photoes,viewGroup,false);
        return new PhotoViewHolder(view);
    }



    @Override
    public void onBindViewHolder(@NonNull final PhotoViewHolder photoViewHolder, int i) {


        int position = photoViewHolder.getAdapterPosition();
        List<Image> list=new ArrayList<>();
        if(getItem(position).getImages()!=null)
        {
            if(getItem(position).getImages().get(0).getLink().contains("jpg") || getItem(position).getImages().get(0).getLink().contains("png"))
            {
                {
                    Picasso.get()
                            .load(getItem(position).getImages().get(0).getLink())
                            .into(photoViewHolder.ivPhoto);
                    id= (getItem(position).getAccountId());
                    imageurl=getItem(position).getImages().get(0).getLink();

                }
            }
        }

        if(getItem(position).getTitle()!=null)
        {
            title=getItem(position).getTitle();
        }
        else
        {
           title="no title";
        }




        photoViewHolder.ivPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: "+"f");



                Intent intent = new Intent(context, description.class);
                intent.putExtra("title",title);
                intent.putExtra("id",id);
                intent.putExtra("url",imageurl);
                context.startActivity(intent);
            }
        });



       // Glide.with(photoViewHolder.itemView.getContext()).load(getItem(i).getUrl()).into(photoViewHolder.ivPhoto);
    }


    public class PhotoViewHolder extends RecyclerView.ViewHolder {
        ImageView ivPhoto;

        public PhotoViewHolder(@NonNull View itemView) {
            super(itemView);
            ivPhoto = itemView.findViewById(R.id.imageView);
        }
    }
}
