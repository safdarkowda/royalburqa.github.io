package com.safdarkowda.cavista.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface BookDAO
{
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun saveBooks(book: BookEntity)

    @Query(value = "Select * from BookEntity")
    fun getAllBooks() : List<BookEntity>
}