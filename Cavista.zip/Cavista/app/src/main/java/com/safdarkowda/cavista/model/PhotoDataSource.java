package com.safdarkowda.cavista.model;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.paging.PageKeyedDataSource;

import com.safdarkowda.cavista.MainActivity;
import com.safdarkowda.cavista.network.GetDataService;
import com.safdarkowda.cavista.network.RetrofitClientInstance;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;

public class PhotoDataSource extends PageKeyedDataSource<Long,Photos> {

    GetDataService dataService;

    @Override
    public void loadInitial(@NonNull LoadInitialParams<Long> params, @NonNull final LoadInitialCallback<Long, Photos> callback) {

        dataService = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
     //   Call<List<Photos>> data = dataService.getAllPhotos(1);
        Call<RegisterBody> data = dataService.getAllPhotos(MainActivity.value,"Client-ID 137cda6b5008a7c");
        data.enqueue(new Callback<RegisterBody>() {
            @Override
            public void onResponse(Call<RegisterBody> call, Response<RegisterBody> response) {
                List<Photos> photosList = response.body().getData();
                callback.onResult(photosList,null,(long)2);
            }

            @Override
            public void onFailure(Call<RegisterBody> call, Throwable t) {
                Log.d(TAG, "onFailure: "+t.getMessage());
            }
        });

    }

    @Override
    public void loadBefore(@NonNull LoadParams<Long> params, @NonNull LoadCallback<Long, Photos> callback) {

    }

    @Override
    public void loadAfter(@NonNull final LoadParams<Long> params, @NonNull final LoadCallback<Long, Photos> callback) {


        dataService = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
    //    Call<List<Photos>> data = dataService.getAllPhotos(params.key);
        Call<RegisterBody> data = dataService.getAllPhotos(MainActivity.value,"Client-ID 137cda6b5008a7c");
        data.enqueue(new Callback<RegisterBody>() {
            @Override
            public void onResponse(Call<RegisterBody> call, Response<RegisterBody> response) {
                List<Photos> photosList = response.body().getData();
                callback.onResult(photosList, ((params.key)+1));
            }

            @Override
            public void onFailure(Call<RegisterBody> call, Throwable t) {

            }
        });


    }
}
